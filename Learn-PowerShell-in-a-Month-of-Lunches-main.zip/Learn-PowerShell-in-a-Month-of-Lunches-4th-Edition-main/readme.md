# Learn PowerShell in a Month of Lunches 4th Edition
Code for the book